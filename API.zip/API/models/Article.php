<?php
class Article {
    private $conn;
    private $table = 'articles';
    private $userTable = 'users';

    public $id;
    public $title;
    public $content;
    public $image_url;
    public $author;
    public $published_date;
    public $category;
    public $views;
    public $reading_time;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getAll() {
        $query = "SELECT a.*, u.name as author, u.avatar as author_avatar 
                  FROM " . $this->table . " a 
                  LEFT JOIN " . $this->userTable . " u ON a.user_id = u.id 
                  WHERE a.is_published = 1 
                  ORDER BY a.published_date DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        $articles = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $articles[] = [
                'id' => $row['id'],
                'title' => $row['title'],
                'content' => $row['content'],
                'image_url' => $row['image_url'],
                'author' => $row['author'],
                'published_date' => $row['published_date'],
                'category' => $row['category'],
                'views' => $row['views'],
                'reading_time' => $row['reading_time'],
                'author_avatar' => $row['author_avatar']
            ];
        }
        return $articles;
    }

    public function getById($id) {
        $query = "SELECT a.*, u.name as author, u.avatar as author_avatar 
                  FROM " . $this->table . " a 
                  LEFT JOIN " . $this->userTable . " u ON a.user_id = u.id 
                  WHERE a.id = :id AND a.is_published = 1 LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        
        if ($stmt->execute()) {
            $article = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Update view count
            if ($article) {
                $updateQuery = "UPDATE " . $this->table . " SET views = views + 1 WHERE id = :id";
                $updateStmt = $this->conn->prepare($updateQuery);
                $updateStmt->bindParam(':id', $id);
                $updateStmt->execute();
            }
            
            return $article;
        }
        return false;
    }
}
?>