<?php
class Task {
    private $conn;
    private $table = 'tasks';

    public $id;
    public $user_id;
    public $title;
    public $description;
    public $is_completed;
    public $due_date;
    public $priority;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getByUserId($user_id) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE user_id = :user_id 
                  ORDER BY due_date ASC, priority DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        
        $tasks = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $tasks[] = [
                'id' => $row['id'],
                'title' => $row['title'],
                'description' => $row['description'],
                'is_completed' => (bool)$row['is_completed'],
                'due_date' => $row['due_date'],
                'priority' => $row['priority']
            ];
        }
        return $tasks;
    }

    public function create($data) {
        $query = "INSERT INTO " . $this->table . " 
                  (user_id, title, description, due_date, priority) 
                  VALUES (:user_id, :title, :description, :due_date, :priority)";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':user_id', $data['user_id']);
        $stmt->bindParam(':title', $data['title']);
        $stmt->bindParam(':description', $data['description']);
        $stmt->bindParam(':due_date', $data['due_date']);
        $priority = isset($data['priority']) ? $data['priority'] : 'medium';
        $stmt->bindParam(':priority', $priority);
        
        return $stmt->execute();
    }

    public function update($id, $data) {
        $query = "UPDATE " . $this->table . " 
                  SET is_completed = :is_completed, 
                      updated_at = NOW() 
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':is_completed', $data['is_completed'], PDO::PARAM_BOOL);
        $stmt->bindParam(':id', $id);
        
        return $stmt->execute();
    }
}
?>