<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

require_once 'config/database.php';
require_once 'models/User.php';
require_once 'models/Article.php';
require_once 'models/Task.php';
require_once 'models/Comment.php';

// Tangkap request method
$method = $_SERVER['REQUEST_METHOD'];
$request = explode('/', trim($_SERVER['PATH_INFO'],'/'));

// Ambil endpoint
$endpoint = array_shift($request);

// Response helper
function jsonResponse($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data);
    exit();
}

// Handle OPTIONS request (CORS)
if ($method == 'OPTIONS') {
    jsonResponse(['message' => 'CORS preflight'], 200);
}

// Routing sederhana
switch($endpoint) {
    case 'login':
        if ($method == 'POST') {
            $data = json_decode(file_get_contents("php://input"));
            $user = new User();
            $result = $user->login($data->email, $data->password);
            
            if ($result) {
                jsonResponse([
                    'success' => true,
                    'message' => 'Login berhasil',
                    'user' => $result
                ]);
            } else {
                jsonResponse([
                    'success' => false,
                    'message' => 'Email atau password salah'
                ], 401);
            }
        }
        break;
        
    case 'articles':
        $article = new Article();
        if ($method == 'GET') {
            // GET /api/articles
            if (empty($request)) {
                $articles = $article->getAll();
                jsonResponse($articles);
            } 
            // GET /api/articles/{id}
            else {
                $id = intval($request[0]);
                $articleData = $article->getById($id);
                
                if ($articleData) {
                    jsonResponse($articleData);
                } else {
                    jsonResponse(['message' => 'Artikel tidak ditemukan'], 404);
                }
            }
        }
        break;
        
    case 'tasks':
        $task = new Task();
        $userId = isset($_GET['user_id']) ? intval($_GET['user_id']) : 1;
        
        if ($method == 'GET') {
            $tasks = $task->getByUserId($userId);
            jsonResponse($tasks);
        }
        // POST /api/tasks
        elseif ($method == 'POST') {
            $data = json_decode(file_get_contents("php://input"));
            $result = $task->create([
                'user_id' => $userId,
                'title' => $data->title,
                'description' => $data->description,
                'due_date' => $data->due_date
            ]);
            
            if ($result) {
                jsonResponse(['success' => true, 'message' => 'Task created']);
            } else {
                jsonResponse(['success' => false, 'message' => 'Failed to create task'], 500);
            }
        }
        // PUT /api/tasks/{id}
        elseif ($method == 'PUT' && !empty($request)) {
            $id = intval($request[0]);
            $data = json_decode(file_get_contents("php://input"));
            $result = $task->update($id, ['is_completed' => $data->is_completed]);
            
            if ($result) {
                jsonResponse(['success' => true, 'message' => 'Task updated']);
            } else {
                jsonResponse(['success' => false, 'message' => 'Failed to update task'], 500);
            }
        }
        break;
        
    case 'users':
        if ($method == 'GET' && !empty($request)) {
            $user = new User();
            $id = intval($request[0]);
            $userData = $user->getById($id);
            
            if ($userData) {
                jsonResponse($userData);
            } else {
                jsonResponse(['message' => 'User tidak ditemukan'], 404);
            }
        }
        break;
        
    default:
        jsonResponse(['message' => 'Endpoint tidak ditemukan'], 404);
        break;
}
?>