package com.example.uas_ridhwanhafizhalghani

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
