import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uas_ridhwanhafizhalghani/models/article.dart';

class ArticleDetailPage extends StatefulWidget {
  final Article article;

  const ArticleDetailPage({Key? key, required this.article}) : super(key: key);

  @override
  _ArticleDetailPageState createState() => _ArticleDetailPageState();
}

class Comment {
  final String id;
  final String name;
  final String avatar;
  final String time;
  final String comment;
  int likes;
  bool isLiked;
  List<Comment> replies;
  bool showReplies;
  bool isReplying;

  Comment({
    required this.id,
    required this.name,
    required this.avatar,
    required this.time,
    required this.comment,
    this.likes = 0,
    this.isLiked = false,
    this.replies = const [],
    this.showReplies = false,
    this.isReplying = false,
  });
}

class _ArticleDetailPageState extends State<ArticleDetailPage> {
  int likeCount = 42;
  bool isLiked = false;
  bool showComments = false;
  bool isBookmarked = false;
  TextEditingController commentController = TextEditingController();
  Map<String, TextEditingController> replyControllers = {};
  int commentIdCounter = 100;

  List<Comment> comments = [
    Comment(
      id: '1',
      name: 'Ahmad Rizki',
      avatar: 'https://i.pravatar.cc/150?img=5',
      time: '2 jam yang lalu',
      comment:
      'Artikel yang sangat bermanfaat! Saya jadi lebih memahami cara mengatur waktu dengan baik.',
      likes: 12,
      replies: [
        Comment(
          id: '1_1',
          name: 'Dewi Lestari',
          avatar: 'https://i.pravatar.cc/150?img=8',
          time: '1 jam yang lalu',
          comment: 'Setuju sekali! Saya juga merasakan manfaatnya.',
          likes: 3,
        ),
      ],
    ),
    Comment(
      id: '2',
      name: 'Siti Nurhaliza',
      avatar: 'https://i.pravatar.cc/150?img=6',
      time: '5 jam yang lalu',
      comment:
      'Tips yang diberikan sangat praktis dan mudah diterapkan. Terima kasih!',
      likes: 8,
    ),
    Comment(
      id: '3',
      name: 'Budi Santoso',
      avatar: 'https://i.pravatar.cc/150?img=7',
      time: 'Kemarin',
      comment:
      'Sebagai mahasiswa, artikel ini sangat membantu meningkatkan produktivitas saya.',
      likes: 15,
      replies: [
        Comment(
          id: '3_1',
          name: 'Admin',
          avatar: 'https://i.pravatar.cc/150?img=2',
          time: '12 jam yang lalu',
          comment: 'Senang bisa membantu! Jangan lupa share ke teman-teman ya.',
          likes: 5,
        ),
      ],
    ),
    Comment(
      id: '4',
      name: 'Dewi Lestari',
      avatar: 'https://i.pravatar.cc/150?img=8',
      time: '2 hari yang lalu',
      comment: 'Materinya lengkap dan penyajiannya menarik. Keep it up!',
      likes: 6,
    ),
  ];

  void _handleLike() {
    setState(() {
      if (!isLiked) {
        likeCount++;
        isLiked = true;
      } else {
        likeCount--;
        isLiked = false;
      }
    });
  }

  void _toggleBookmark() {
    setState(() {
      isBookmarked = !isBookmarked;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            isBookmarked
                ? 'Artikel ditambahkan ke bookmark'
                : 'Artikel dihapus dari bookmark',
          ),
          duration: Duration(seconds: 1),
        ),
      );
    });
  }

  void _toggleComments() {
    setState(() {
      showComments = !showComments;
    });
  }

  void _likeComment(String commentId) {
    setState(() {
      Comment? comment = _findCommentById(comments, commentId);
      if (comment != null) {
        if (!comment.isLiked) {
          comment.likes++;
          comment.isLiked = true;
        } else {
          comment.likes--;
          comment.isLiked = false;
        }
      }
    });
  }

  Comment? _findCommentById(List<Comment> commentList, String id) {
    for (var comment in commentList) {
      if (comment.id == id) return comment;
      var found = _findCommentById(comment.replies, id);
      if (found != null) return found;
    }
    return null;
  }

  void _toggleReplies(String commentId) {
    setState(() {
      Comment? comment = _findCommentById(comments, commentId);
      if (comment != null) {
        comment.showReplies = !comment.showReplies;
      }
    });
  }

  void _toggleReplyInput(String commentId) {
    setState(() {
      Comment? comment = _findCommentById(comments, commentId);
      if (comment != null) {
        comment.isReplying = !comment.isReplying;
        if (comment.isReplying && !replyControllers.containsKey(commentId)) {
          replyControllers[commentId] = TextEditingController();
        }
      }
    });
  }

  void _addComment() {
    if (commentController.text.trim().isNotEmpty) {
      setState(() {
        commentIdCounter++;
        comments.insert(
            0,
            Comment(
              id: commentIdCounter.toString(),
              name: 'Anda',
              avatar: 'https://i.pravatar.cc/150?img=1',
              time: 'Baru saja',
              comment: commentController.text.trim(),
              likes: 0,
              isLiked: false,
            ));
        commentController.clear();
      });

      Future.delayed(Duration(milliseconds: 100), () {
        Scrollable.ensureVisible(
          context,
          duration: Duration(milliseconds: 300),
        );
      });
    }
  }

  void _addReply(String parentCommentId) {
    final controller = replyControllers[parentCommentId];
    if (controller != null && controller.text.trim().isNotEmpty) {
      setState(() {
        Comment? parentComment = _findCommentById(comments, parentCommentId);
        if (parentComment != null) {
          commentIdCounter++;
          parentComment.replies.add(Comment(
            id: '${parentCommentId}_${commentIdCounter}',
            name: 'Anda',
            avatar: 'https://i.pravatar.cc/150?img=1',
            time: 'Baru saja',
            comment: controller.text.trim(),
            likes: 0,
            isLiked: false,
          ));
          parentComment.isReplying = false;
          controller.clear();
        }
      });
    }
  }

  int _countTotalComments() {
    int total = comments.length;
    for (var comment in comments) {
      total += comment.replies.length;
    }
    return total;
  }

  @override
  void dispose() {
    commentController.dispose();
    replyControllers.values.forEach((controller) => controller.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 250,
            floating: false,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Image.network(
                widget.article.imageUrl,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => Container(
                  color: Colors.grey[300],
                  child: Center(
                    child: Icon(Icons.image_not_supported_rounded,
                        color: Colors.grey[500]),
                  ),
                ),
              ),
              title: Text(
                '',
                style: TextStyle(
                  fontSize: 16,
                  shadows: [
                    Shadow(
                      color: Colors.black,
                      blurRadius: 10,
                    ),
                  ],
                ),
              ),
            ),
            leading: IconButton(
              icon: Container(
                padding: EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.arrow_back_rounded, color: Colors.white),
              ),
              onPressed: () => Navigator.pop(context),
            ),
            actions: [
              IconButton(
                icon: Container(
                  padding: EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: Colors.black54,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(Icons.share_rounded, color: Colors.white),
                ),
                onPressed: () {},
              ),
              IconButton(
                icon: Container(
                  padding: EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: Colors.black54,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    isBookmarked
                        ? Icons.bookmark_rounded
                        : Icons.bookmark_border_rounded,
                    color: isBookmarked ? Colors.blue[300] : Colors.white,
                  ),
                ),
                onPressed: _toggleBookmark,
              ),
            ],
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.blue[50],
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.blue[100]!),
                    ),
                    child: Text(
                      'Produktivitas',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.blue[800],
                      ),
                    ),
                  ),
                  SizedBox(height: 16),
                  Text(
                    widget.article.title,
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey[900],
                      height: 1.3,
                    ),
                  ),
                  SizedBox(height: 20),
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 20,
                        backgroundImage: NetworkImage(
                          'https://i.pravatar.cc/150?img=${widget.article.id}',
                          scale: 1.0,
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              widget.article.author,
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Colors.grey[800],
                              ),
                            ),
                            Text(
                              'Penulis Artikel',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.calendar_today_rounded,
                                  size: 14, color: Colors.grey[600]),
                              SizedBox(width: 4),
                              Text(
                                DateFormat('dd MMM yyyy')
                                    .format(widget.article.publishedDate),
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey[600],
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 4),
                          Row(
                            children: [
                              Icon(Icons.access_time_rounded,
                                  size: 14, color: Colors.grey[600]),
                              SizedBox(width: 4),
                              Text(
                                '${(widget.article.content.length / 200).ceil()} min read',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey[600],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(height: 25),
                  Divider(),
                  SizedBox(height: 25),
                  // Konten artikel berdasarkan judul
                  _buildArticleContent(),
                  SizedBox(height: 30),
                  // Quote Box
                  Container(
                    padding: EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.blue[50],
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: Colors.blue[100]!),
                    ),
                    child: Column(
                      children: [
                        Icon(Icons.format_quote_rounded,
                            size: 30, color: Colors.blue[300]),
                        SizedBox(height: 10),
                        Text(
                          '"Produktivitas adalah kemampuan untuk melakukan hal-hal yang sebelumnya tidak pernah bisa Anda lakukan."',
                          style: TextStyle(
                            fontSize: 16,
                            fontStyle: FontStyle.italic,
                            color: Colors.grey[700],
                            height: 1.5,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: 10),
                        Text(
                          '- Franz Kafka',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 30),
                  // Action Buttons
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _handleLike,
                          icon: Icon(
                            isLiked ? Icons.thumb_up : Icons.thumb_up_rounded,
                            color: isLiked ? Colors.blue[800] : null,
                          ),
                          label: Text('Suka ($likeCount)'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                            isLiked ? Colors.blue[100] : Colors.blue[50],
                            foregroundColor: Colors.blue[800],
                            padding: EdgeInsets.symmetric(vertical: 15),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 10),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _toggleComments,
                          icon: Icon(Icons.comment_rounded),
                          label: Text('Komentar (${_countTotalComments()})'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: showComments
                                ? Colors.green[100]
                                : Colors.green[50],
                            foregroundColor: Colors.green[800],
                            padding: EdgeInsets.symmetric(vertical: 15),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),

                  // Komentar Section
                  if (showComments) ...[
                    SizedBox(height: 25),
                    Text(
                      'Komentar',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey[900],
                      ),
                    ),
                    SizedBox(height: 15),
                    ...comments
                        .map((comment) => _buildCommentItem(comment))
                        .toList(),
                    SizedBox(height: 20),
                    // Input Komentar Baru
                    Container(
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.grey[50],
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.grey[200]!),
                      ),
                      child: Column(
                        children: [
                          TextField(
                            controller: commentController,
                            decoration: InputDecoration(
                              hintText: 'Tulis komentar Anda...',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                                borderSide: BorderSide.none,
                              ),
                              filled: true,
                              fillColor: Colors.white,
                              contentPadding: EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 12,
                              ),
                              suffixIcon: commentController.text.isNotEmpty
                                  ? IconButton(
                                icon: Icon(Icons.send_rounded,
                                    color: Colors.blue[800]),
                                onPressed: _addComment,
                              )
                                  : null,
                            ),
                            maxLines: 3,
                            minLines: 1,
                            onChanged: (value) {
                              setState(() {});
                            },
                            onSubmitted: (value) {
                              if (value.trim().isNotEmpty) {
                                _addComment();
                              }
                            },
                          ),
                          SizedBox(height: 10),
                          if (commentController.text.isNotEmpty)
                            Align(
                              alignment: Alignment.centerRight,
                              child: ElevatedButton.icon(
                                onPressed: _addComment,
                                icon: Icon(Icons.send_rounded, size: 18),
                                label: Text('Kirim Komentar'),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.blue[600],
                                  foregroundColor: Colors.white,
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 20,
                                    vertical: 10,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                    SizedBox(height: 30),
                  ],

                  SizedBox(height: 30),
                  // Artikel Terkait
                  Text(
                    'Artikel Terkait',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey[900],
                    ),
                  ),
                  SizedBox(height: 15),
                  _buildRelatedArticle(),
                  SizedBox(height: 50),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildArticleContent() {
    // Menentukan konten berdasarkan judul artikel
    if (widget.article.title.contains('10 Tips Produktivitas')) {
      return _buildProductivityTipsContent();
    } else if (widget.article.title.contains('Flutter untuk Pemula')) {
      return _buildFlutterGuideContent();
    } else if (widget.article.title.contains('Manajemen Stress')) {
      return _buildStressManagementContent();
    } else if (widget.article.title.contains('Portfolio')) {
      return _buildPortfolioContent();
    } else {
      return Text(
        widget.article.content,
        style: TextStyle(
          fontSize: 16,
          height: 1.8,
          color: Colors.grey[800],
        ),
      );
    }
  }

  Widget _buildProductivityTipsContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Sebagai mahasiswa, mengelola waktu dengan efektif adalah kunci kesuksesan. Berikut adalah 10 tips produktivitas yang bisa Anda terapkan:',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 20),
        _buildNumberedTip(
          number: 1,
          title: 'Buat Rencana Harian',
          content: 'Mulai hari dengan membuat to-do list. Prioritaskan tugas berdasarkan deadline dan tingkat kesulitan. Gunakan aplikasi seperti Google Calendar atau Notion untuk membantu perencanaan.',
        ),
        _buildNumberedTip(
          number: 2,
          title: 'Teknik Pomodoro',
          content: 'Bagi waktu belajar menjadi 25 menit fokus diikuti 5 menit istirahat. Setelah 4 siklus, ambil istirahat 15-30 menit. Teknik ini membantu menjaga fokus dan mengurangi kelelahan mental.',
        ),
        _buildNumberedTip(
          number: 3,
          title: 'Hindari Multitasking',
          content: 'Fokus pada satu tugas hingga selesai. Multitasking mengurangi kualitas pekerjaan dan membutuhkan waktu 40% lebih lama untuk menyelesaikan tugas.',
        ),
        _buildNumberedTip(
          number: 4,
          title: 'Atur Lingkungan Belajar',
          content: 'Ciptakan ruang belajar yang bersih, terang, dan bebas gangguan. Matikan notifikasi ponsel dan gunakan headphone noise-cancelling jika diperlukan.',
        ),
        _buildNumberedTip(
          number: 5,
          title: 'Gunakan Metode SMART',
          content: 'Tujuan harus Specific, Measurable, Achievable, Relevant, dan Time-bound. Contoh: "Selesaikan 3 bab mata kuliah dalam 2 hari" lebih efektif daripada "Belajar banyak".',
        ),
        _buildNumberedTip(
          number: 6,
          title: 'Istirahat yang Cukup',
          content: 'Tidur 7-8 jam per hari meningkatkan daya ingat dan konsentrasi. Hindari begadang karena mengurangi produktivitas keesokan harinya.',
        ),
        _buildNumberedTip(
          number: 7,
          title: 'Review Mingguan',
          content: 'Evaluasi pencapaian mingguan setiap Jumat malam. Identifikasi hambatan dan sesuaikan strategi untuk minggu berikutnya.',
        ),
        _buildNumberedTip(
          number: 8,
          title: 'Belajar Efektif',
          content: 'Gunakan metode Feynman: jelaskan materi dengan bahasa sederhana. Ajarkan kepada teman untuk memperkuat pemahaman.',
        ),
        _buildNumberedTip(
          number: 9,
          title: 'Manfaatkan Teknologi',
          content: 'Gunakan aplikasi seperti Forest untuk fokus, Quizlet untuk flashcard, dan Trello untuk manajemen proyek. Otomatisasi tugas berulang jika memungkinkan.',
        ),
        _buildNumberedTip(
          number: 10,
          title: 'Jaga Keseimbangan',
          content: 'Sisihkan waktu untuk olahraga, hobi, dan sosialisasi. Produktivitas bukan tentang bekerja terus-menerus, tetapi tentang keseimbangan hidup.',
        ),
        SizedBox(height: 20),
        Text(
          'Dengan menerapkan tips-tips ini secara konsisten, Anda akan melihat peningkatan signifikan dalam produktivitas dan prestasi akademik.',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
      ],
    );
  }

  Widget _buildFlutterGuideContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Flutter adalah framework open-source Google untuk membangun aplikasi mobile yang indah, dikompilasi secara native, untuk iOS dan Android dari satu basis kode. Berikut panduan lengkap untuk pemula:',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 20),
        _buildSubtitle('Apa itu Flutter?'),
        Text(
          'Flutter menggunakan bahasa pemrograman Dart dan menyediakan widget yang kaya untuk membangun UI yang responsif. Keunggulannya termasuk hot reload yang mempercepat pengembangan, performa tinggi karena kompilasi native, dan UI yang konsisten di semua platform.',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 15),
        _buildSubtitle('Instalasi dan Setup'),
        Text(
          '1. Download Flutter SDK dari flutter.dev\n2. Ekstrak ke folder yang diinginkan\n3. Tambahkan path ke environment variable\n4. Jalankan "flutter doctor" untuk memeriksa dependencies\n5. Install Android Studio atau VS Code dengan extension Flutter',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 15),
        _buildSubtitle('Struktur Proyek Flutter'),
        Text(
          '• lib/main.dart: Entry point aplikasi\n• pubspec.yaml: Konfigurasi dependensi\n• android/: File native Android\n• ios/: File native iOS\n• assets/: Gambar, font, dan file statis',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 15),
        _buildSubtitle('Widget Dasar'),
        Text(
          'Flutter menggunakan widget sebagai building block:\n• StatelessWidget: UI statis\n• StatefulWidget: UI yang bisa berubah\n• Container: Box layout\n• Column/Row: Layout vertikal/horizontal\n• Text, Image, Icon: Widget dasar',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 15),
        _buildSubtitle('Best Practices'),
        Text(
          '1. Pisahkan UI dan logic\n2. Gunakan state management yang sesuai\n3. Optimasi performa dengan const widget\n4. Implementasi error handling\n5. Testing: unit test, widget test, integration test',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
      ],
    );
  }

  Widget _buildStressManagementContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Tugas kuliah, ujian, dan tekanan akademik seringkali menyebabkan stress pada mahasiswa. Berikut strategi manajemen stress yang efektif:',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 20),
        _buildSubtitle('Identifikasi Sumber Stress'),
        Text(
          'Kenali pemicu stress Anda:\n• Deadline tugas yang berdekatan\n• Beban mata kuliah yang berat\n• Perfeksionisme dan tekanan diri sendiri\n• Masalah finansial\n• Konflik sosial atau keluarga',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 15),
        _buildSubtitle('Teknik Relaksasi'),
        Text(
          '1. Pernapasan dalam: Tarik napas 4 detik, tahan 7 detik, hembuskan 8 detik\n2. Meditasi 10 menit sehari\n3. Progressive muscle relaxation: tegang dan lemaskan otot bertahap\n4. Visualisasi tempat yang tenang\n5. Musik relaksasi atau white noise',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 15),
        _buildSubtitle('Manajemen Waktu untuk Kurangi Stress'),
        Text(
          '• Buat jadwal realistis dengan buffer time\n• Gunakan teknik Eisenhower Matrix untuk prioritas\n• Break down tugas besar menjadi bagian kecil\n• Delegasikan jika memungkinkan\n• Belajar mengatakan "tidak" pada komitmen berlebihan',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 15),
        _buildSubtitle('Dukungan Sosial'),
        Text(
          '1. Bicarakan masalah dengan teman atau keluarga\n2. Ikut kelompok studi untuk support akademik\n3. Konsultasi dengan dosen pembimbing\n4. Gunakan layanan konseling kampus\n5. Bergabung dengan komunitas atau organisasi kampus',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 15),
        _buildSubtitle('Gaya Hidup Sehat'),
        Text(
          '• Olahraga 30 menit, 3-4 kali seminggu\n• Pola makan seimbang dan teratur\n• Tidur 7-8 jam setiap malam\n• Batasi kafein dan gula\n• Luangkan waktu untuk hobi dan relaksasi',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
      ],
    );
  }

  Widget _buildPortfolioContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Portfolio yang baik adalah kunci untuk memulai karir di bidang IT. Berikut panduan membangun portfolio yang menarik bagi recruiter:',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 20),
        _buildSubtitle('Struktur Portfolio yang Efektif'),
        Text(
          '1. Landing page dengan personal branding yang kuat\n2. About me: Ceritakan passion dan tujuan karir\n3. Skills: Teknis (programming, tools) dan soft skills\n4. Projects: 3-5 proyek terbaik dengan detail lengkap\n5. Experience: Magang, freelance, atau proyek akademik\n6. Contact: Email, LinkedIn, GitHub, dan media profesional',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 15),
        _buildSubtitle('Proyek yang Harus Dimiliki'),
        Text(
          '• Aplikasi CRUD lengkap dengan backend\n• Website responsif dengan teknologi modern (React, Vue, dll)\n• Aplikasi mobile (Flutter, React Native)\n• Proyek open source kontribusi\n• Case study dengan problem-solving yang jelas',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 15),
        _buildSubtitle('Teknik Presentasi Proyek'),
        Text(
          'Gunakan formula STAR:\n• Situation: Konteks proyek\n• Task: Tujuan yang ingin dicapai\n• Action: Teknologi dan metode yang digunakan\n• Result: Outcome dan metrik keberhasilan\n\nTambahkan: Screenshot, demo video, link live demo, dan kode sumber.',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 15),
        _buildSubtitle('Platform untuk Portfolio'),
        Text(
          '1. GitHub untuk kode sumber\n2. LinkedIn untuk profil profesional\n3. Personal website (Gatsby, Next.js, WordPress)\n4. Behance/Dribbble untuk desain UI/UX\n5. Medium/Dev.to untuk technical writing\n6. YouTube untuk demo dan tutorial',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 15),
        _buildSubtitle('Tips dari Recruiter IT'),
        Text(
          '• Quality over quantity: 3 proyek bagus lebih baik dari 10 biasa\n• Dokumentasi kode yang rapi dan README informatif\n• Sertakan testimonials atau feedback klien\n• Update portfolio secara berkala\n• Customize untuk setiap lamaran pekerjaan',
          style: TextStyle(
            fontSize: 16,
            height: 1.8,
            color: Colors.grey[800],
          ),
        ),
      ],
    );
  }

  Widget _buildNumberedTip({required int number, required String title, required String content}) {
    return Padding(
      padding: EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: Colors.blue,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Center(
                  child: Text(
                    '$number',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey[900],
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      content,
                      style: TextStyle(
                        fontSize: 16,
                        height: 1.6,
                        color: Colors.grey[800],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSubtitle(String text) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Colors.grey[900],
        ),
      ),
    );
  }

  Widget _buildCommentItem(Comment comment) {
    return Column(
      children: [
        Container(
          margin: EdgeInsets.only(bottom: 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 20,
                backgroundImage: NetworkImage(
                  comment.avatar,
                  scale: 1.0,
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: comment.name == 'Anda'
                        ? Colors.blue[50]
                        : Colors.grey[50],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            comment.name,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: comment.name == 'Anda'
                                  ? Colors.blue[800]
                                  : Colors.grey[800],
                            ),
                          ),
                          SizedBox(width: 8),
                          Text(
                            '• ${comment.time}',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey[500],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 6),
                      Text(
                        comment.comment,
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[700],
                          height: 1.4,
                        ),
                      ),
                      SizedBox(height: 8),
                      Row(
                        children: [
                          // Tombol Like Komentar
                          TextButton.icon(
                            onPressed: () => _likeComment(comment.id),
                            icon: Icon(
                              comment.isLiked
                                  ? Icons.thumb_up_rounded
                                  : Icons.thumb_up_outlined,
                              size: 14,
                              color: comment.isLiked
                                  ? Colors.blue[600]
                                  : Colors.grey[600],
                            ),
                            label: Text(
                              'Suka${comment.likes > 0 ? ' (${comment.likes})' : ''}',
                              style: TextStyle(
                                color: comment.isLiked
                                    ? Colors.blue[600]
                                    : Colors.grey[600],
                              ),
                            ),
                            style: TextButton.styleFrom(
                              padding: EdgeInsets.zero,
                              minimumSize: Size.zero,
                              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            ),
                          ),
                          SizedBox(width: 16),
                          // Tombol Balas
                          TextButton.icon(
                            onPressed: () => _toggleReplyInput(comment.id),
                            icon: Icon(Icons.reply_rounded,
                                size: 14, color: Colors.grey[600]),
                            label: Text('Balas'),
                            style: TextButton.styleFrom(
                              padding: EdgeInsets.zero,
                              minimumSize: Size.zero,
                              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            ),
                          ),
                          Spacer(),
                          // Tombol Tampilkan Balasan
                          if (comment.replies.isNotEmpty)
                            TextButton(
                              onPressed: () => _toggleReplies(comment.id),
                              child: Row(
                                children: [
                                  Icon(
                                    comment.showReplies
                                        ? Icons.keyboard_arrow_up_rounded
                                        : Icons.keyboard_arrow_down_rounded,
                                    size: 16,
                                    color: Colors.grey[600],
                                  ),
                                  SizedBox(width: 4),
                                  Text(
                                    '${comment.replies.length} balasan',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                ],
                              ),
                              style: TextButton.styleFrom(
                                padding: EdgeInsets.zero,
                                minimumSize: Size.zero,
                                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),

        // Input Balasan
        if (comment.isReplying)
          Padding(
            padding: EdgeInsets.only(left: 52, bottom: 12),
            child: Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey[50],
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.grey[200]!),
              ),
              child: Column(
                children: [
                  TextField(
                    controller: replyControllers[comment.id],
                    decoration: InputDecoration(
                      hintText: 'Tulis balasan...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(6),
                        borderSide: BorderSide.none,
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding: EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 10,
                      ),
                      suffixIcon:
                      replyControllers[comment.id]?.text.isNotEmpty ?? false
                          ? IconButton(
                        icon: Icon(Icons.send_rounded,
                            size: 18, color: Colors.blue[600]),
                        onPressed: () => _addReply(comment.id),
                      )
                          : null,
                    ),
                    maxLines: 2,
                    minLines: 1,
                    onChanged: (value) {
                      setState(() {});
                    },
                    onSubmitted: (value) {
                      if (value.trim().isNotEmpty) {
                        _addReply(comment.id);
                      }
                    },
                  ),
                  SizedBox(height: 8),
                  if (replyControllers[comment.id]?.text.isNotEmpty ?? false)
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton(
                          onPressed: () => _toggleReplyInput(comment.id),
                          child: Text('Batal'),
                          style: TextButton.styleFrom(
                            foregroundColor: Colors.grey[600],
                          ),
                        ),
                        SizedBox(width: 8),
                        ElevatedButton(
                          onPressed: () => _addReply(comment.id),
                          child: Text('Kirim Balasan'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue[600],
                            foregroundColor: Colors.white,
                            padding: EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(6),
                            ),
                          ),
                        ),
                      ],
                    ),
                ],
              ),
            ),
          ),

        // Daftar Balasan
        if (comment.showReplies && comment.replies.isNotEmpty)
          Padding(
            padding: EdgeInsets.only(left: 52),
            child: Column(
              children: comment.replies
                  .map((reply) => _buildCommentItem(reply))
                  .toList(),
            ),
          ),
      ],
    );
  }

  Widget _buildRelatedArticle() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 6,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 120,
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(12),
                topRight: Radius.circular(12),
              ),
              image: DecorationImage(
                image: NetworkImage(
                  'https://picsum.photos/300/200?random=3',
                ),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Tips Manajemen Waktu untuk Mahasiswa',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
                SizedBox(height: 8),
                Row(
                  children: [
                    CircleAvatar(
                      radius: 12,
                      backgroundImage: NetworkImage(
                        'https://i.pravatar.cc/150?img=2',
                        scale: 1.0,
                      ),
                    ),
                    SizedBox(width: 8),
                    Text(
                      'Admin',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[600],
                      ),
                    ),
                    Spacer(),
                    Icon(Icons.visibility_rounded,
                        size: 12, color: Colors.grey[500]),
                    SizedBox(width: 4),
                    Text(
                      '240 views',
                      style: TextStyle(
                        fontSize: 11,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

