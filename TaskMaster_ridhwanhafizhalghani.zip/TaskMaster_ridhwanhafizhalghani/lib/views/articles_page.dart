import 'package:flutter/material.dart';
import 'package:uas_ridhwanhafizhalghani/models/article.dart';
import 'package:uas_ridhwanhafizhalghani/services/api_service.dart';
import 'package:uas_ridhwanhafizhalghani/widgets/custom_snackbar.dart';
import 'article_detail_page.dart'; // TAMBAH IMPORT INI

class ArticlesPage extends StatefulWidget {
  @override
  _ArticlesPageState createState() => _ArticlesPageState();
}

class _ArticlesPageState extends State<ArticlesPage> {
  List<Article> _articles = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadArticles();
  }

  void _loadArticles() async {
    try {
      final articles = await ApiService.getArticles();
      setState(() {
        _articles = articles;
        _isLoading = false;
      });
    } catch (e) {
      CustomSnackbar.show(context, 'Gagal memuat artikel');
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Artikel'), // TAMBAH APPBAR
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _articles.isEmpty
          ? Center(child: Text('Tidak ada artikel'))
          : ListView.builder(
        padding: EdgeInsets.all(10),
        itemCount: _articles.length,
        itemBuilder: (context, index) {
          final article = _articles[index];
          return Card(
            margin: EdgeInsets.symmetric(vertical: 8),
            child: ListTile(
              leading: Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  image: DecorationImage(
                    image: NetworkImage(article.imageUrl),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              title: Text(
                article.title,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                'Oleh: ${article.author}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        ArticleDetailPage(article: article),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
