import 'package:flutter/material.dart';
import 'package:uas_ridhwanhafizhalghani/models/task.dart'; // IMPORT YANG BENAR
import 'package:uas_ridhwanhafizhalghani/services/api_service.dart';
import 'package:uas_ridhwanhafizhalghani/widgets/custom_snackbar.dart';

class TasksPage extends StatefulWidget {
  @override
  _TasksPageState createState() => _TasksPageState();
}

class _TasksPageState extends State<TasksPage> {
  List<Task> _tasks = [];
  bool _isLoading = true;
  final TextEditingController _taskController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadTasks();
  }

  void _loadTasks() async {
    try {
      final tasks = await ApiService.getTasks();
      setState(() {
        _tasks = tasks;
        _isLoading = false;
      });
    } catch (e) {
      CustomSnackbar.show(context, 'Gagal memuat tugas');
      setState(() => _isLoading = false);
    }
  }

  void _addTask() {
    if (_taskController.text.isEmpty) {
      CustomSnackbar.show(context, 'Masukkan nama tugas!');
      return;
    }

    final newTask = Task(
      id: _tasks.length + 1,
      title: _taskController.text,
      description: 'Tugas baru',
      isCompleted: false,
      dueDate: DateTime.now().add(Duration(days: 1)),
    );

    setState(() {
      _tasks.add(newTask);
      _taskController.clear();
    });

    CustomSnackbar.show(context, 'Tugas berhasil ditambahkan!');
  }

  void _toggleTask(int index) {
    setState(() {
      _tasks[index] = Task(
        id: _tasks[index].id,
        title: _tasks[index].title,
        description: _tasks[index].description,
        isCompleted: !_tasks[index].isCompleted,
        dueDate: _tasks[index].dueDate,
      );
    });
  }

  void _deleteTask(int index) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Hapus Tugas'),
        content: Text('Apakah Anda yakin ingin menghapus tugas "${_tasks[index].title}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Batal'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                _tasks.removeAt(index);
              });
              Navigator.pop(context);
              CustomSnackbar.show(context, 'Tugas berhasil dihapus!');
            },
            child: Text('Hapus', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tugas'), // TAMBAH APPBAR
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _taskController,
                    decoration: InputDecoration(
                      labelText: 'Tambah tugas baru',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                ElevatedButton(
                  onPressed: _addTask,
                  child: Icon(Icons.add),
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.all(15),
                    shape: CircleBorder(),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: _isLoading
                ? Center(child: CircularProgressIndicator())
                : _tasks.isEmpty
                ? Center(child: Text('Tidak ada tugas'))
                : ListView.builder(
              padding: EdgeInsets.all(10),
              itemCount: _tasks.length,
              itemBuilder: (context, index) {
                final task = _tasks[index];
                return Container(
                  margin: EdgeInsets.symmetric(vertical: 4),
                  decoration: BoxDecoration(
                    color: task.isCompleted
                        ? Colors.green.shade50
                        : Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: CheckboxListTile(
                          title: Text(
                            task.title,
                            style: TextStyle(
                              fontSize: 16,
                              decoration: task.isCompleted
                                  ? TextDecoration.lineThrough
                                  : TextDecoration.none,
                            ),
                          ),
                          subtitle: Text(
                            'Deadline: ${task.dueDate.toString().split(' ')[0]}',
                          ),
                          value: task.isCompleted,
                          onChanged: (value) => _toggleTask(index),
                          secondary: Icon(
                            task.isCompleted
                                ? Icons.check_circle
                                : Icons.radio_button_unchecked,
                            color: task.isCompleted
                                ? Colors.green
                                : Colors.grey,
                          ),
                        ),
                      ),
                      // Tombol hapus hanya ditampilkan untuk tugas yang sudah selesai
                      if (task.isCompleted)
                        IconButton(
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed: () => _deleteTask(index),
                          tooltip: 'Hapus tugas',
                        ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

