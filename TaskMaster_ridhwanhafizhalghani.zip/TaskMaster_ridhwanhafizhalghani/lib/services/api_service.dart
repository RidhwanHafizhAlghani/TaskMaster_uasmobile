import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:uas_ridhwanhafizhalghani/models/user.dart';
import 'package:uas_ridhwanhafizhalghani/models/article.dart';
import 'package:uas_ridhwanhafizhalghani/models/task.dart';

class ApiService {
  // Ubah baseUrl ke localhost dengan port XAMPP
  static const String baseUrl = 'http://10.0.2.2/backend/api';

  // Method Register
  static Future<User?> register(String name, String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/register'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'name': name,
          'email': email,
          'password': password,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          final userData = data['user'];
          return User(
            id: userData['id'],
            name: userData['name'],
            email: userData['email'],
            avatar: userData['avatar'],
          );
        }
      }
      return null;
    } catch (e) {
      print('Register error: $e');
      return null;
    }
  }

  // Method Login (DIMODIFIKASI)
  static Future<User?> login(String email, String password) async {
    try {
      // SIMULASI LOGIN TANPA API (karena API belum ada)
      if (email == 'ridhwanhafizh@gmail.com' && password == 'ridhwan123') {
        // Return user data sesuai dengan yang ada di database
        return User(
          id: 1,
          name: 'Ridhwan Hafizh Al Ghani',
          email: 'ridhwanhafizh@gmail.com',
          avatar: 'https://i.pravatar.cc/150?img=1',
        );
      }

      // Jika email/password salah
      return null;
    } catch (e) {
      print('Login error: $e');
      return null;
    }
  }

  // Method untuk mengambil artikel (DIMODIFIKASI untuk simulasi)
  static Future<List<Article>> getArticles() async {
    try {
      // Simulasi data artikel
      return [
        Article(
          id: 1,
          title: '10 Tips Produktivitas untuk Mahasiswa',
          content: 'Konten artikel pertama tentang produktivitas...',
          imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80',
          author: 'Dr. Andi Wijaya',
          publishedDate: DateTime(2024, 5, 15),
          category: 'Produktivitas',
          views: 1245,
          readingTime: 8,
        ),
        Article(
          id: 2,
          title: 'Flutter untuk Pemula: Panduan Lengkap',
          content: 'Konten artikel kedua tentang Flutter...',
          imageUrl: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=1374&q=80',
          author: 'Budi Santoso',
          publishedDate: DateTime(2024, 5, 12),
          category: 'Teknologi',
          views: 876,
          readingTime: 10,
        ),
        Article(
          id: 3,
          title: 'Manajemen Stress dalam Menyelesaikan Tugas Kuliah',
          content: 'Konten artikel ketiga tentang manajemen stress...',
          imageUrl: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1420&q=80',
          author: 'Maria Sari',
          publishedDate: DateTime(2024, 5, 10),
          category: 'Kesehatan',
          views: 543,
          readingTime: 6,
        ),
      ];
    } catch (e) {
      print('Get articles error: $e');
      return [];
    }
  }

  // Method untuk mengambil tugas (DIMODIFIKASI untuk simulasi)
  static Future<List<Task>> getTasks() async {
    try {
      // Simulasi data tugas
      return [
        Task(
          id: 1,
          title: 'Selesaikan UAS Mobile Computing',
          description: 'Buat aplikasi Flutter dengan fitur login, artikel, dan tugas',
          isCompleted: false,
          dueDate: DateTime.now().add(Duration(days: 7)),
        ),
        Task(
          id: 2,
          title: 'Belajar API Integration di Flutter',
          description: 'Pelajari cara koneksi ke REST API menggunakan package http',
          isCompleted: true,
          dueDate: DateTime.now().subtract(Duration(days: 2)),
        ),
        Task(
          id: 3,
          title: 'Revisi Paper Metodologi Penelitian',
          description: 'Perbaiki bab 3 sesuai masukan dosen pembimbing',
          isCompleted: false,
          dueDate: DateTime.now().add(Duration(days: 3)),
        ),
      ];
    } catch (e) {
      print('Get tasks error: $e');
      return [];
    }
  }

  // Method lainnya tetap sama
  static Future<bool> createTask(String title, String description, DateTime dueDate) async {
    try {
      // Simulasi sukses
      await Future.delayed(Duration(seconds: 1));
      return true;
    } catch (e) {
      print('Create task error: $e');
      return false;
    }
  }

  static Future<bool> updateTask(int taskId, bool isCompleted) async {
    try {
      // Simulasi sukses
      await Future.delayed(Duration(seconds: 1));
      return true;
    } catch (e) {
      print('Update task error: $e');
      return false;
    }
  }
}