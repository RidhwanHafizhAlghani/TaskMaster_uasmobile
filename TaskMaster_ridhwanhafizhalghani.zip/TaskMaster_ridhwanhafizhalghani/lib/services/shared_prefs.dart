import 'package:shared_preferences/shared_preferences.dart';

class SharedPrefs {
  static late SharedPreferences _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static Future<void> saveLoginData(String email, String name) async {
    await _prefs.setString('email', email);
    await _prefs.setString('name', name);
    await _prefs.setBool('isLoggedIn', true);
  }

  static bool isLoggedIn() {
    return _prefs.getBool('isLoggedIn') ?? false;
  }

  static String getEmail() {
    return _prefs.getString('email') ?? '';
  }

  static String getName() {
    return _prefs.getString('name') ?? '';
  }

  static Future<void> logout() async {
    await _prefs.clear();
  }
}
