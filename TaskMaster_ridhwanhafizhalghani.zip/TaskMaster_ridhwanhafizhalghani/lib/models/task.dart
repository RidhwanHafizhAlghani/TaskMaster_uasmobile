class Task {
  int id;
  String title;
  String description;
  bool isCompleted;
  DateTime dueDate;

  Task({
    required this.id,
    required this.title,
    required this.description,
    required this.isCompleted,
    required this.dueDate,
  });

  factory Task.fromJson(Map<String, dynamic> json) {
    return Task(
      id: json['id'] ?? 0,
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      isCompleted: json['is_completed'] == 1,
      dueDate: DateTime.parse(json['due_date'] ?? DateTime.now().toString()),
    );
  }
}
