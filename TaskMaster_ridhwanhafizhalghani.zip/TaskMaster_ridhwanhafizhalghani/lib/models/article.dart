class Article {
  int id;
  String title;
  String content;
  String imageUrl;
  String author;
  DateTime publishedDate;
  String category;
  int views;
  int readingTime;
  String? authorAvatar;

  Article({
    required this.id,
    required this.title,
    required this.content,
    required this.imageUrl,
    required this.author,
    required this.publishedDate,
    this.category = 'Produktivitas',
    this.views = 0,
    this.readingTime = 5,
    this.authorAvatar,
  });

  factory Article.fromJson(Map<String, dynamic> json) {
    return Article(
      id: json['id'] ?? 0,
      title: json['title'] ?? '',
      content: json['content'] ?? '',
      imageUrl: json['image_url'] ?? '',
      author: json['author'] ?? '',
      publishedDate: DateTime.parse(json['published_date'] ?? DateTime.now().toString()),
      category: json['category'] ?? 'Produktivitas',
      views: json['views'] ?? 0,
      readingTime: json['reading_time'] ?? 5,
      authorAvatar: json['author_avatar'],
    );
  }
}