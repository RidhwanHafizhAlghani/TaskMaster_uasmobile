-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 22, 2026 at 10:03 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `task_master`
--

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `add_comment`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_comment` (IN `p_article_id` INT, IN `p_user_id` INT, IN `p_parent_id` INT, IN `p_content` TEXT)   BEGIN
    INSERT INTO comments (article_id, user_id, parent_id, content)
    VALUES (p_article_id, p_user_id, p_parent_id, p_content);
    
    -- Update artikel view count
    UPDATE articles SET views = views + 1 WHERE id = p_article_id;
END$$

DROP PROCEDURE IF EXISTS `add_new_task`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_new_task` (IN `p_user_id` INT, IN `p_title` VARCHAR(200), IN `p_description` TEXT, IN `p_due_date` DATE, IN `p_priority` ENUM('low','medium','high'))   BEGIN
    INSERT INTO tasks (user_id, title, description, due_date, priority)
    VALUES (p_user_id, p_title, p_description, p_due_date, p_priority);
END$$

DROP PROCEDURE IF EXISTS `toggle_article_like`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `toggle_article_like` (IN `p_user_id` INT, IN `p_article_id` INT)   BEGIN
    DECLARE v_exists INT;
    
    SELECT COUNT(*) INTO v_exists 
    FROM article_likes 
    WHERE user_id = p_user_id AND article_id = p_article_id;
    
    IF v_exists > 0 THEN
        DELETE FROM article_likes WHERE user_id = p_user_id AND article_id = p_article_id;
    ELSE
        INSERT INTO article_likes (user_id, article_id) VALUES (p_user_id, p_article_id);
    END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` longtext NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `category` varchar(50) DEFAULT 'Produktivitas',
  `views` int(11) DEFAULT 0,
  `reading_time` int(11) DEFAULT 5,
  `is_published` tinyint(1) DEFAULT 1,
  `published_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `user_id`, `title`, `content`, `image_url`, `category`, `views`, `reading_time`, `is_published`, `published_date`, `created_at`, `updated_at`) VALUES
(1, 2, '10 Tips Produktivitas untuk Mahasiswa', 'Konten artikel pertama...', 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80', 'Produktivitas', 1245, 8, 1, '2024-05-15', '2026-01-22 08:14:00', '2026-01-22 08:14:00'),
(2, 3, 'Flutter untuk Pemula: Panduan Lengkap Pengembangan Aplikasi Mobile', 'Konten artikel kedua...', 'https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1374&q=80', 'Teknologi', 876, 10, 1, '2024-05-12', '2026-01-22 08:14:00', '2026-01-22 08:14:00'),
(3, 4, 'Manajemen Stress dalam Menyelesaikan Tugas Kuliah', 'Konten artikel ketiga...', 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1420&q=80', 'Kesehatan', 543, 6, 1, '2024-05-10', '2026-01-22 08:14:00', '2026-01-22 08:14:00'),
(4, 2, 'Membangun Portfolio untuk Karir di Bidang IT', 'Konten artikel keempat...', 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80', 'Karir', 987, 12, 1, '2024-05-08', '2026-01-22 08:14:00', '2026-01-22 08:14:00');

-- --------------------------------------------------------

--
-- Stand-in structure for view `article_details`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `article_details`;
CREATE TABLE `article_details` (
`id` int(11)
,`title` varchar(200)
,`content` longtext
,`image_url` varchar(255)
,`category` varchar(50)
,`views` int(11)
,`reading_time` int(11)
,`published_date` date
,`author` varchar(100)
,`author_avatar` varchar(255)
,`like_count` bigint(21)
,`comment_count` bigint(21)
,`bookmark_count` bigint(21)
);

-- --------------------------------------------------------

--
-- Table structure for table `article_likes`
--

DROP TABLE IF EXISTS `article_likes`;
CREATE TABLE `article_likes` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `article_likes`
--

INSERT INTO `article_likes` (`id`, `user_id`, `article_id`, `created_at`) VALUES
(1, 1, 1, '2026-01-22 08:14:01'),
(2, 1, 2, '2026-01-22 08:14:01'),
(3, 3, 1, '2026-01-22 08:14:01'),
(4, 4, 1, '2026-01-22 08:14:01'),
(5, 2, 2, '2026-01-22 08:14:01');

-- --------------------------------------------------------

--
-- Table structure for table `bookmarks`
--

DROP TABLE IF EXISTS `bookmarks`;
CREATE TABLE `bookmarks` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookmarks`
--

INSERT INTO `bookmarks` (`id`, `user_id`, `article_id`, `created_at`) VALUES
(1, 1, 1, '2026-01-22 08:14:01'),
(2, 1, 3, '2026-01-22 08:14:01'),
(3, 1, 4, '2026-01-22 08:14:01');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `content` text NOT NULL,
  `likes` int(11) DEFAULT 0,
  `is_liked_by_user` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `article_id`, `user_id`, `parent_id`, `content`, `likes`, `is_liked_by_user`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, 'Artikel yang sangat bermanfaat! Saya jadi lebih memahami cara mengatur waktu dengan baik.', 12, 0, '2026-01-22 08:14:00', '2026-01-22 08:14:00'),
(2, 1, 3, NULL, 'Tips yang diberikan sangat praktis dan mudah diterapkan. Terima kasih!', 8, 0, '2026-01-22 08:14:00', '2026-01-22 08:14:00'),
(3, 1, 4, NULL, 'Sebagai mahasiswa, artikel ini sangat membantu meningkatkan produktivitas saya.', 15, 0, '2026-01-22 08:14:00', '2026-01-22 08:14:00'),
(4, 1, 2, 3, 'Senang bisa membantu! Jangan lupa share ke teman-teman ya.', 5, 0, '2026-01-22 08:14:00', '2026-01-22 08:14:00'),
(5, 1, 4, NULL, 'Materinya lengkap dan penyajiannya menarik. Keep it up!', 6, 0, '2026-01-22 08:14:00', '2026-01-22 08:14:00');

-- --------------------------------------------------------

--
-- Table structure for table `comment_likes`
--

DROP TABLE IF EXISTS `comment_likes`;
CREATE TABLE `comment_likes` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `is_completed` tinyint(1) DEFAULT 0,
  `due_date` date NOT NULL,
  `priority` enum('low','medium','high') DEFAULT 'medium',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `user_id`, `title`, `description`, `is_completed`, `due_date`, `priority`, `created_at`, `updated_at`) VALUES
(1, 1, 'Selesaikan UAS Mobile Computing', 'Buat aplikasi Flutter dengan fitur login, artikel, dan tugas. Presentasikan hasilnya di depan dosen.', 0, '2024-06-10', 'high', '2026-01-22 08:14:00', '2026-01-22 08:14:00'),
(2, 1, 'Belajar API Integration di Flutter', 'Pelajari cara koneksi ke REST API menggunakan package http. Implementasikan CRUD operations.', 1, '2024-05-18', 'medium', '2026-01-22 08:14:00', '2026-01-22 08:14:00'),
(3, 1, 'Revisi Paper Metodologi Penelitian', 'Perbaiki bab 3 sesuai masukan dosen pembimbing. Tambahkan referensi terbaru tahun 2024.', 0, '2024-05-22', 'high', '2026-01-22 08:14:00', '2026-01-22 08:14:00'),
(4, 1, 'Presentasi Projek AI', 'Siapkan slide presentasi untuk projek machine learning. Latihan presentasi minimal 3 kali.', 0, '2024-05-20', 'high', '2026-01-22 08:14:00', '2026-01-22 08:14:00'),
(5, 1, 'Studi Kasus Database', 'Analisis performa query pada database besar. Buat laporan optimisasi dengan benchmark.', 1, '2024-05-15', 'low', '2026-01-22 08:14:00', '2026-01-22 08:14:00'),
(6, 1, 'Kerjakan Soal Algoritma', 'Selesaikan 10 soal algoritma dari platform HackerRank. Fokus pada dynamic programming.', 0, '2024-05-25', 'medium', '2026-01-22 08:14:00', '2026-01-22 08:14:00'),
(7, 1, 'Rapat Tim Projek', 'Koordinasi dengan tim mengenai progress dan pembagian tugas untuk sprint berikutnya.', 0, '2024-05-21', 'medium', '2026-01-22 08:14:00', '2026-01-22 08:14:00'),
(8, 1, 'Perbaiki Bug di Aplikasi', 'Fix critical bug di module payment. Test semua scenario sebelum deploy ke production.', 1, '2024-05-19', 'high', '2026-01-22 08:14:00', '2026-01-22 08:14:00');

-- --------------------------------------------------------

--
-- Stand-in structure for view `upcoming_tasks`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `upcoming_tasks`;
CREATE TABLE `upcoming_tasks` (
`id` int(11)
,`title` varchar(200)
,`description` text
,`is_completed` tinyint(1)
,`due_date` date
,`priority` enum('low','medium','high')
,`user_name` varchar(100)
,`user_email` varchar(100)
,`days_remaining` int(7)
);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `avatar`, `created_at`, `updated_at`) VALUES
(1, 'Ridhwan Hafizh Al Ghani', 'ridhwan@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'https://i.pravatar.cc/150?img=1', '2026-01-22 08:14:00', '2026-01-22 08:14:00'),
(2, 'Dr. Andi Wijaya', 'andi@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'https://i.pravatar.cc/150?img=2', '2026-01-22 08:14:00', '2026-01-22 08:14:00'),
(3, 'Budi Santoso', 'budi@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'https://i.pravatar.cc/150?img=3', '2026-01-22 08:14:00', '2026-01-22 08:14:00'),
(4, 'Maria Sari', 'maria@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'https://i.pravatar.cc/150?img=4', '2026-01-22 08:14:00', '2026-01-22 08:14:00');

-- --------------------------------------------------------

--
-- Stand-in structure for view `user_dashboard`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `user_dashboard`;
CREATE TABLE `user_dashboard` (
`user_id` int(11)
,`name` varchar(100)
,`email` varchar(100)
,`avatar` varchar(255)
,`total_tasks` bigint(21)
,`completed_tasks` decimal(22,0)
,`bookmarked_articles` bigint(21)
,`liked_articles` bigint(21)
,`total_comments` bigint(21)
);

-- --------------------------------------------------------

--
-- Structure for view `article_details`
--
DROP TABLE IF EXISTS `article_details`;

DROP VIEW IF EXISTS `article_details`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `article_details`  AS SELECT `a`.`id` AS `id`, `a`.`title` AS `title`, `a`.`content` AS `content`, `a`.`image_url` AS `image_url`, `a`.`category` AS `category`, `a`.`views` AS `views`, `a`.`reading_time` AS `reading_time`, `a`.`published_date` AS `published_date`, `u`.`name` AS `author`, `u`.`avatar` AS `author_avatar`, count(distinct `al`.`id`) AS `like_count`, count(distinct `c`.`id`) AS `comment_count`, count(distinct `b`.`id`) AS `bookmark_count` FROM ((((`articles` `a` join `users` `u` on(`a`.`user_id` = `u`.`id`)) left join `article_likes` `al` on(`a`.`id` = `al`.`article_id`)) left join `comments` `c` on(`a`.`id` = `c`.`article_id`)) left join `bookmarks` `b` on(`a`.`id` = `b`.`article_id`)) GROUP BY `a`.`id`, `a`.`title`, `a`.`content`, `a`.`image_url`, `a`.`category`, `a`.`views`, `a`.`reading_time`, `a`.`published_date`, `u`.`name`, `u`.`avatar` ;

-- --------------------------------------------------------

--
-- Structure for view `upcoming_tasks`
--
DROP TABLE IF EXISTS `upcoming_tasks`;

DROP VIEW IF EXISTS `upcoming_tasks`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `upcoming_tasks`  AS SELECT `t`.`id` AS `id`, `t`.`title` AS `title`, `t`.`description` AS `description`, `t`.`is_completed` AS `is_completed`, `t`.`due_date` AS `due_date`, `t`.`priority` AS `priority`, `u`.`name` AS `user_name`, `u`.`email` AS `user_email`, to_days(`t`.`due_date`) - to_days(curdate()) AS `days_remaining` FROM (`tasks` `t` join `users` `u` on(`t`.`user_id` = `u`.`id`)) WHERE `t`.`is_completed` = 0 ORDER BY `t`.`due_date` ASC ;

-- --------------------------------------------------------

--
-- Structure for view `user_dashboard`
--
DROP TABLE IF EXISTS `user_dashboard`;

DROP VIEW IF EXISTS `user_dashboard`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `user_dashboard`  AS SELECT `u`.`id` AS `user_id`, `u`.`name` AS `name`, `u`.`email` AS `email`, `u`.`avatar` AS `avatar`, count(distinct `t`.`id`) AS `total_tasks`, sum(case when `t`.`is_completed` = 1 then 1 else 0 end) AS `completed_tasks`, count(distinct `b`.`id`) AS `bookmarked_articles`, count(distinct `al`.`id`) AS `liked_articles`, count(distinct `c`.`id`) AS `total_comments` FROM ((((`users` `u` left join `tasks` `t` on(`u`.`id` = `t`.`user_id`)) left join `bookmarks` `b` on(`u`.`id` = `b`.`user_id`)) left join `article_likes` `al` on(`u`.`id` = `al`.`user_id`)) left join `comments` `c` on(`u`.`id` = `c`.`user_id`)) GROUP BY `u`.`id`, `u`.`name`, `u`.`email`, `u`.`avatar` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_published_date` (`published_date`),
  ADD KEY `idx_category` (`category`);

--
-- Indexes for table `article_likes`
--
ALTER TABLE `article_likes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_like` (`user_id`,`article_id`),
  ADD KEY `article_id` (`article_id`);

--
-- Indexes for table `bookmarks`
--
ALTER TABLE `bookmarks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_bookmark` (`user_id`,`article_id`),
  ADD KEY `article_id` (`article_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_article_id` (`article_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_parent_id` (`parent_id`);

--
-- Indexes for table `comment_likes`
--
ALTER TABLE `comment_likes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_comment_like` (`user_id`,`comment_id`),
  ADD KEY `comment_id` (`comment_id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_due_date` (`due_date`),
  ADD KEY `idx_is_completed` (`is_completed`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `article_likes`
--
ALTER TABLE `article_likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `bookmarks`
--
ALTER TABLE `bookmarks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `comment_likes`
--
ALTER TABLE `comment_likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `articles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `article_likes`
--
ALTER TABLE `article_likes`
  ADD CONSTRAINT `article_likes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `article_likes_ibfk_2` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `bookmarks`
--
ALTER TABLE `bookmarks`
  ADD CONSTRAINT `bookmarks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bookmarks_ibfk_2` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comments_ibfk_3` FOREIGN KEY (`parent_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `comment_likes`
--
ALTER TABLE `comment_likes`
  ADD CONSTRAINT `comment_likes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comment_likes_ibfk_2` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

